---
name: deploy-nova-app
description: Exports the NOVA app built in the current conversation as a static, credential-free bundle and deploys it to the local web server (C:\xx_Ismael\MyWeb, served at http://10.240.33.208:8080/). Use this skill whenever the user wants to deploy, publish, host, ship, copy to the web server, or "put online" a NOVA or ArcGIS app from this conversation, or asks for the URL where the app can be opened, even if they don't say "deploy".
compatibility: Requires the `export_app` tool, the `arcgis-app` skill, and file-system write access to C:\xx_Ismael\MyWeb (e.g. Claude Code or Cowork running on that machine, or a filesystem connector).
---

# Deploy a NOVA app to the local web server

## Configuration

- Web root (local path): `C:\xx_Ismael\MyWeb\`
- Web root (URL): `http://10.240.33.208:8080/`
- A file at `C:\xx_Ismael\MyWeb\<folder>\index.html` is served at `http://10.240.33.208:8080/<folder>/index.html`.

## Step 1: Export the app bundle

1. Identify the NOVA app produced in the current conversation. If there is more than one, or none, ask the user which app to deploy.
2. If the app path, export mode, or bundle contents are unclear, read the `arcgis-app` skill first.
3. Decide the folder name the app will live in on the server (default: the app's name in kebab-case). The deployed URL depends on it, and OAuth needs that URL in advance.
4. Choose the export mode:
   - **public**: only when every referenced layer, map, and service is anonymously accessible. If you cannot confirm this, ask the user rather than guessing.
   - **OAuth**: in every other case. Ask the user for the public OAuth client ID, the portal URL, and the registered redirect URI. Tell them the redirect URI should match the deployed location, normally `http://10.240.33.208:8080/<folder>/` (or the exact callback page the app uses). Never fall back to public because OAuth inputs are missing.
5. Run `export_app`. Use the bundle path or file reference returned in the result as the source. Never build a path from memory or guess an output location, because a wrong source silently deploys the wrong files.
6. If the export fails, report the exact error message and stop.

## Step 2: Copy the bundle to the web server

1. Copy the whole bundle into `C:\xx_Ismael\MyWeb\<folder>\`, preserving its directory structure. Do not spread bundle files into the web root itself, since that mixes them with other sites.
2. If `<folder>` already exists, list what is there and ask the user before replacing anything. Never touch files outside `<folder>`.
3. If the destination is inaccessible or the user declines, stop and say so. Do not report the copy as done.

## Step 3: Verify

Use the cheapest check available: confirm `<folder>` exists and contains the entry point (e.g. `index.html`) and the other files listed by the export. Note any file that is missing.

## Step 4: Report

Reply using this template. Never include credentials, tokens, or client secrets in the bundle or in the reply (a public OAuth client ID is fine).

```
Source bundle:   <path returned by export_app>
Destination:     C:\xx_Ismael\MyWeb\<folder>\
Auth mode:       public | OAuth (portal: <portal URL>)
Existing files:  none | replaced: ... | skipped: ... | untouched: ...
Verification:    passed | failed: <what is missing>
App URL:         http://10.240.33.208:8080/<folder>/index.html
```
